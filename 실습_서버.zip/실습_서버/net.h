#pragma once

bool net_initlibrary();
void net_exitlibrary();

SOCKET net_create_socket(int port);
void net_delete_socket(SOCKET a);
