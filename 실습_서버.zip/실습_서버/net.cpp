#include "std.h"

bool net_initlibrary()
{
	WSADATA wsa;

	if (WSAStartup((MAKEWORD(2, 2)), &wsa) != 0)
	{
		return false;
	}
	return true;
}
void net_exitlibrary()
{
	WSACleanup();
}

SOCKET net_create_socket(int port)
{
	SOCKET listen_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (listen_socket == INVALID_SOCKET)
	{
		printf(" ���� ���� ����\n");
		return 0;
	}
	SOCKADDR_IN addr;
	memset(&addr, 0, sizeof(SOCKADDR_IN));

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(port);

	int ret = bind(listen_socket, (SOCKADDR*)&addr, sizeof(addr));
	if (ret == SOCKET_ERROR)
	{
		printf(" bind  ����\n");
		return 0;
	}

	ret = listen(listen_socket, SOMAXCONN);
	if (ret == SOCKET_ERROR)
	{
		printf(" listen  ����\n");
		return 0;
	}

	return listen_socket;
}
void net_delete_socket(SOCKET a)
{
	closesocket(a);
}