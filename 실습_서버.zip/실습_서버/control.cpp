#include "std.h"

SOCKET listen_socket;
vector <AddMemberPacket> members;

HANDLE hThread;

void con_init()
{
	// ���� ����.
	if (net_initlibrary() == false)
	{
		printf(" ���� �ʱ�ȭ����\n\n");
		return;
	}
	listen_socket = net_create_socket(SERVER_PORT);
	if (listen_socket == 0)
	{
		printf(" ���� ���� ���� \n\n");
		return ;
	}
}
void con_run()
{	
	// ��� ������
	
	printf("------ ���� ��� ------\n\n\n");
	hThread = CreateThread(0, 0, listen_thread, 0, 0, 0);
	if (hThread == 0)
	{
		printf(" �������������� \n");
		return;
	}
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	
}
void con_exit()
{
	net_delete_socket(listen_socket);
	net_exitlibrary();
}

unsigned long CALLBACK listen_thread(void* temp)
{	
	SOCKADDR_IN client_addr;
	int client_length = sizeof(SOCKADDR_IN);

	while (true)
	{		
		memset(&client_addr, 0, sizeof(SOCKADDR_IN));
		SOCKET c_socket = accept(listen_socket, (SOCKADDR*)&client_addr, &client_length);
		if (c_socket == INVALID_SOCKET)
		{
			printf(" accept  ����\n");
			Sleep(2000);
			continue;
		}
		printf("------ ���� ���� : (%s : %d )------\n\n\n",
			inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

		// ��� ���� �� ������ ����
		HANDLE hThread = CreateThread(0, 0, work_thread, (void*)c_socket, 0, 0);
		if (hThread == 0)
		{
			printf(" workthread ����\n");
			return -1;
		}

		CloseHandle(hThread);
	}
	return 0;
}
unsigned long CALLBACK work_thread(void* p)
{	// ��� ���� ����
	SOCKET client_socket = (SOCKET)p;
	char buf[1024];

	while (true)
	{
		memset(buf, 0, sizeof(buf));
		int recv_byte = recv_data(client_socket, buf, sizeof(buf), 0);
		if (recv_byte == 0)
		{
			printf("------ ���� ������ ������ϴ� ------\n\n");
			break;
		}
		else if (recv_byte == -1)
		{
			printf("\n\n  ERROR  \n\n");
			break;
		}
		else
		{
			char FLAG[20];
			int* flag = (int*)buf;
			switch (*flag)
			{
			case PACKET_ADD_MEMBER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "�߰�");
				break;
			}
			case PACKET_SEL_MEMBER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "�˻�");
				break;
			}
			case PACKET_MOD_MEMBER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "����");
				break;
			}
			case PACKET_DEL_MEMBER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "����");
				break;
			}
			}
			SOCKADDR_IN client_addr;
			int client_length = sizeof(SOCKADDR);
			getpeername(client_socket, (SOCKADDR*)&client_addr, &client_length);

			printf(">> [����] IP : %s �������� : %s <<\n\n" , 
				inet_ntoa(client_addr.sin_addr) , FLAG);
			// �޼��� �Ľ�
			int size = msg_parsing(buf);
			int send_byte = send_data(client_socket, buf, size, 0);
			printf(">> [�۽�] IP : %s <<\n\n" , inet_ntoa(client_addr.sin_addr));
		}
	}

	SOCKADDR_IN client_addr;
	int client_length = sizeof(SOCKADDR);

	getpeername(client_socket, (SOCKADDR*)&client_addr, &client_length);

	printf("------ Ŭ���̾�Ʈ ���� ���� (IP :%s ) ------\n\n\n",
		inet_ntoa(client_addr.sin_addr));
	
	closesocket(client_socket);
	return 0;
}

int msg_parsing(char* msg)
{	
	int* flag = (int*)msg;

	// ��� �߰�
	if (*flag == PACKET_ADD_MEMBER)
	{
		AddMemberPacket* add = (AddMemberPacket*)msg;
		AddMemberPacket member;

		strcpy_s(member.name, sizeof(member.name), add->name);
		strcpy_s(member.phone, sizeof(member.phone), add->phone);
		member.age = add->age;

		members.push_back(member);

		// ���� �޼��� ����
		AddMemberAckPacket ack;
		ack.flag = PACKET_ADD_MEMBER_S;
		strcpy_s(ack.name, sizeof(ack.name), member.name);
		// ���ۿ� ����
		memcpy_s(msg, sizeof(AddMemberAckPacket), (char*)&ack, sizeof(AddMemberAckPacket));
		return sizeof(AddMemberAckPacket);
	}
	// ��� �˻�
	else if (*flag == PACKET_SEL_MEMBER)
	{
		SelMemberPacket* sel = (SelMemberPacket*)msg;
		SelMemberPacket member;

		strcpy_s(member.name, sizeof(member.name), sel->name);

		AddMemberPacket cmp;
		memset(&cmp, 0, sizeof(cmp));
		int result = 0;
		for(int i=0; i<members.size(); i++)
		{
			cmp = members[i];
			if (strcmp(member.name, cmp.name) == 0)
			{
				result = PACKET_SEL_MEMBER_S;
			}
		}
		if (result == PACKET_SEL_MEMBER_S)
		{
			member.flag = PACKET_SEL_MEMBER_S;
		}
		else
		{
			member.flag = PACKET_SEL_MEMBER_F;
			memcpy_s(msg, sizeof(AddMemberPacket), &member, sizeof(AddMemberPacket));
			return sizeof(AddMemberPacket);
		}

		// ������
		SelMemberAckPacket ack;
		ack.flag = member.flag;
		strcpy_s(ack.name, sizeof(ack.name), member.name);
		strcpy_s(ack.phone, sizeof(ack.phone), cmp.phone);
		ack.age = cmp.age;

		memcpy_s(msg, sizeof(SelMemberAckPacket), &ack, sizeof(SelMemberAckPacket));
		return sizeof(SelMemberAckPacket);
	}
	// ��� ����
	else if (*flag == PACKET_MOD_MEMBER)
	{
		ModMemberPacket* mod = (ModMemberPacket*)msg;
		ModMemberPacket member;

		// �̸� �˻�.
		strcpy_s(member.name, sizeof(member.name), mod->name);
		strcpy_s(member.phone, sizeof(member.phone), mod->phone);
		member.age = mod->age;

		ModMemberPacket cmp;
		int result = 0;
		int index  = 0;
		// �˻�
		for (int i = 0; i < members.size(); i++)
		{
			cmp = members[i];
			if (strcmp(member.name, cmp.name) == 0)
			{		
				index = i;
				result = PACKET_MOD_MEMBER_S;
			}
		}
		// flag �޾��ֱ�
		if (result == PACKET_MOD_MEMBER_S)
		{
			member.flag = PACKET_MOD_MEMBER_S;
		}
		else
		{
			member.flag = PACKET_MOD_MEMBER_F;
			memcpy_s(msg, sizeof(ModMemberPacket), &member, sizeof(ModMemberPacket));
			return sizeof(ModMemberPacket);
		}
		
		// ���� �ȿ� �ִ� �̸� ����
		strcpy_s(members[index].phone, sizeof(members[index].phone), member.phone);
		members[index].age = member.age;

		// ������
		ModMemberAckPacket ack;
		ack.flag = member.flag;
		strcpy_s(ack.name, sizeof(ack.name), member.name);
		strcpy_s(ack.phone, sizeof(ack.phone), member.phone);
		ack.age = member.age;

		memcpy_s(msg, sizeof(ModMemberAckPacket), &ack, sizeof(ModMemberAckPacket));
		return sizeof(ModMemberAckPacket);
	}
	// ��� ����
	else if (*flag == PACKET_DEL_MEMBER)
	{
		DelMemberPacket* mod = (DelMemberPacket*)msg;
		DelMemberPacket member;

		// �̸� �˻�.
		strcpy_s(member.name, sizeof(member.name), mod->name);		

		ModMemberPacket cmp;
		int result = 0;
		int index = 0;
		// �˻�
		for (int i = 0; i < members.size(); i++)
		{
			cmp = members[i];
			if (strcmp(member.name, cmp.name) == 0)
			{
				index = i;
				result = PACKET_DEL_MEMBER_S;
			}
		}
		// flag �޾��ֱ�
		if (result == PACKET_DEL_MEMBER_S)
		{
			member.flag = PACKET_DEL_MEMBER_S;
		}
		else
		{
			member.flag = PACKET_DEL_MEMBER_F;
			memcpy_s(msg, sizeof(DelMemberPacket), &member, sizeof(DelMemberPacket));
			return sizeof(DelMemberPacket);
		}

		members.erase(members.begin() + index);

		DelMemberAckPacket ack;
		ack.flag = member.flag;
		strcpy_s(ack.name, sizeof(ack.name), member.name);

		memcpy_s(msg, sizeof(DelMemberAckPacket), &ack, sizeof(DelMemberAckPacket));
		return sizeof(DelMemberAckPacket);
	}

	return 0;
}