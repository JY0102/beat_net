#pragma once


int msg_parsing(char* msg);

unsigned long CALLBACK listen_thread(void* temp);
unsigned long CALLBACK work_thread(void* p);

void con_init();
void con_run();
void con_exit();


