#include "std.h"

int main()
{
	app_init();
		
	app_run();

	app_exit();

	return 0;
}




