#pragma once

#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <Windows.h>	
#include <winsock2.h>
#include <vector>
using namespace std;

#define		SERVER_PORT 5000
#define		BUF_SIZE	2048
#define		PATH_SIZE	260
#define		PATH		"C:\\00_myfilelist\\"

#include "define.h"
#include "file.h"
#include "member.h"
#include "net.h"
#include "packet.h"
#include "control.h"
#include "app.h"