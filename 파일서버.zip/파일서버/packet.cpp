#include "std.h"

FileListAckPacket pack_FileList(char(*filenames)[30] , int size)
{
	FileListAckPacket packet;

	packet.flag = PACK_FILE_LIST_ACK;
	packet.count = size;
	for (int i = 0; i < size; i++)
	{
		strcpy_s(packet.filename[i], sizeof(packet.filename[i]), filenames[i]);
	}
	return packet;
}
FileDownloadAckPacket pack_FileDownload()
{
	FileDownloadAckPacket packet;
	memset(&packet, 0, sizeof(FileDownloadAckPacket));
	packet.flag = PACK_FILE_DOWNLOAD_ACK;

	return packet;
}

