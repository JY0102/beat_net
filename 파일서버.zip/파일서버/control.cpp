#include "std.h"

char filenames[50][30];
int  file_size;
char g_filename[30];

void con_init()
{
	// ���� ����.
	if (net_initlibrary() == false)
	{
		printf(" ���� �ʱ�ȭ����\n\n");
		return;
	}	
	if (net_create_socket(SERVER_PORT) == false)
	{
		printf(" ���� ���� ���� \n\n");
		return ;
	}
}
void con_run()
{	
	net_CreateThread();
}
void con_exit()
{
	net_delete_socket();
	net_exitlibrary();
}

int msg_parsing(char* msg)
{	
	int* flag = (int*)msg;
	// ��� �߰�
	switch (*flag)
	{
	case PACK_FILE_LIST:		return filelist((FileListPacket*)msg);
	case PACK_FILE_DOWNLOAD:	return filedownload((FileDownloadPacket*)msg);
	}

	return 0;
}

int filelist(FileListPacket* packet)
{	
	MyFindFile(filenames, &file_size);

	FileListAckPacket ack = pack_FileList(filenames , file_size);
	memcpy_s(packet, sizeof(FileListAckPacket), (char*)&ack, sizeof(FileListAckPacket));

	return sizeof(FileListAckPacket);
}
int filedownload(FileDownloadPacket* packet)
{		
	memset(g_filename, 0, sizeof(g_filename));
	strcpy_s(g_filename, sizeof(g_filename), packet->filename);
	CloseHandle(CreateThread(0, 0, file_serverconnect, (void*)g_filename, 0, 0));
	FileDownloadAckPacket ack = pack_FileDownload();
	memcpy_s(packet, sizeof(FileDownloadAckPacket), (char*)&ack, sizeof(FileDownloadAckPacket));

	return sizeof(FileDownloadAckPacket);
}

void MyFindFile(char (*filenames)[30], int* size)
{

	char path[PATH_SIZE];
	wsprintf(path, "%s*.*", PATH);
	printf("%s\n", path);

	WIN32_FIND_DATA wfd;
	HANDLE hSrch = FindFirstFile(path, &wfd);
	if (hSrch == INVALID_HANDLE_VALUE) return;

	TCHAR fname[MAX_PATH];
	BOOL bResult = TRUE;
	int count = 0;
	while (bResult)
	{
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
			//wsprintf(fname, "[ %s ]", wfd.cFileName);
		}
		else
		{
			wsprintf(fname, "%s", wfd.cFileName);
			strcpy_s(filenames[count], sizeof(filenames[count]), fname);
			count++;
		}
		bResult = FindNextFile(hSrch, &wfd);
	}
	FindClose(hSrch);
	*size = count;
}
