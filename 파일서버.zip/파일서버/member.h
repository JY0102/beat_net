#pragma once


struct Member
{
	char name[20];
	char phone[20];
	int age;
};