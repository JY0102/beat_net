#pragma once

bool net_initlibrary();
void net_exitlibrary();

bool net_create_socket(int port);
void net_delete_socket();
void net_CreateThread();

int send_data(SOCKET s, char* buf, int len, int flag);
int recv_data(SOCKET s, char* buf, int len, int flag);
int recvn(SOCKET s, char* buf, int len, int flag);

unsigned long CALLBACK listen_thread(void* temp);
unsigned long CALLBACK work_thread(void* p);
