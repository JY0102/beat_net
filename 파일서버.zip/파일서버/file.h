#pragma once


unsigned long CALLBACK FileServer(void* p);
unsigned long CALLBACK file_serverconnect(void* p);
