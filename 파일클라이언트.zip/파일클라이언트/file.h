#pragma once

DWORD WINAPI FileClient(void* p);

void file_RecvFile(HWND hDlg);
