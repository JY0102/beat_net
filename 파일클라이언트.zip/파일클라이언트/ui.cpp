﻿//ui.cpp
#include "std.h"

HWND hListBox;

void ui_InitControl(HWND hDlg)
{
	hListBox = GetDlgItem(hDlg, IDC_LIST1);

	SetDlgItemText(hDlg, IDC_IPADDRESS1, TEXT("192.168.0.39"));
	SetDlgItemInt(hDlg, IDC_EDITPORT, 5000 , 0);
}

void ui_SetDownLoad(HWND hDlg)
{
	TCHAR filename[100];
	memset(filename, 0, sizeof(filename));
	int index = SendMessage(hListBox, LB_GETCURSEL, 0, 0);
	SendMessage(hListBox, LB_GETTEXT, (WPARAM)index, (LPARAM)filename);
	if (filename == 0)return;

	SetDlgItemText(hDlg, IDC_EDITDOWN, filename);
	return;
}
void ui_GetDownLoad(HWND hDlg ,char* filename, int size)
{
	GetDlgItemTextA(hDlg, IDC_EDITDOWN, filename, size);
}

void ui_FileList_Print(const char(*filenames)[30], int size)
{
	ui_Reset(0);

	for(int i=0; i<size; i++)
	{
		SendMessage(hListBox, LB_ADDSTRING, 0, (LPARAM)filenames[i]);
	}
}
void ui_Reset(HWND hDlg)
{
	if(hDlg != 0)
	{
		SetDlgItemText(hDlg, IDC_EDITDOWN, _T(""));
	}
	SendMessage(hListBox, LB_RESETCONTENT, 0, 0);
}

