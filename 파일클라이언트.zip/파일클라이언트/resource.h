//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 0327_FileClient.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDC_BUTTONFILE                  1001
#define IDC_BUTTONCONNECT               1002
#define IDC_LIST1                       1003
#define IDC_EDITPORT                    1005
#define IDC_BUTTONEXIT                  1006
#define IDC_IPADDRESS1                  1007
#define IDC_EDITDOWN                    1008
#define IDC_BUTTONDOWN                  1009
#define IDC_BUTTONDOWNLOAD              1009
#define IDC_LIST2                       1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
