//control.cpp
#include "std.h"


#define SERVER_IP	"192.168.0.39"		//cmd >> ipconfig
#define SERVER_PORT		5000

HWND g_hDlg;

void con_Init(HWND hDlg)
{
	g_hDlg = hDlg;
	ui_InitControl(hDlg);
}

void con_ServerConnect(HWND hDlg)
{
	if (net_initlibrary() == false)
	{
		printf("���� �ʱ�ȭ ����\n");
		//EndDialog(hDlg, IDCANCEL);
	}

	if (net_create_socket(SERVER_IP, SERVER_PORT) == false)
	{
		MessageBox(hDlg, TEXT("�����������"), TEXT("�˸�"), MB_OK);
		//EndDialog(hDlg, IDCANCEL);
	}
}
void con_ServerDisConnect(HWND hDlg)
{
	ui_Reset(hDlg);
	net_delete_socket();
	net_exitlibrary();
	MessageBox(hDlg, TEXT("������������ ����"), TEXT("�˸�"), MB_OK);
}


void con_SetDownload(HWND hDlg)
{
	ui_SetDownLoad(hDlg);
}
//---------- �۽��Լ��� ------------
void con_FileList()
{
	
	FileListPacket packet;
	packet.flag = PACK_FILE_LIST;
	send_data((char*)&packet, sizeof(FileListPacket), 0);
}
void con_FileDownLoad(HWND hDlg)
{
	file_RecvFile(hDlg);
	FileDownloadPacket packet = pack_FileDownLoad(hDlg);
	send_data((char*)&packet, sizeof(FileDownloadPacket), 0);
}
void con_Donwload(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	FileInfoPacket* file_info = (FileInfoPacket*)lParam;
	MessageBox(hDlg, _T("�ٿ��"), _T(""), MB_OK);
}
//---------- �����Լ��� ------------
void msg_parsing(char* buf)
{
	//�Ľ�
	switch (*(int*)buf)
	{
	case PACK_FILE_LIST_ACK:		return file_list_ack(true ,(FileListAckPacket*)buf);
	case PACK_FILE_DOWNLOAD_ACK:	return file_download_ack(true ,(FileDownloadAckPacket*)buf);
	}
}
void file_list_ack(bool flag, FileListAckPacket* packet)
{
	if (flag == true)
	{		
		ui_FileList_Print(packet->filename, packet->count);
	}
	else
		MessageBox(NULL, TEXT("���ϸ���Ʈ ����"), TEXT("���ϸ���Ʈ"), MB_OK);
}
void file_download_ack(bool flag, FileDownloadAckPacket* packet)
{
	if (flag == true)
	{
		// ���� �ٿ� ���
	}
	else
		MessageBox(NULL, TEXT("���ϴٿ�ε� ����"), TEXT("���ϴٿ�ε�"), MB_OK);
}