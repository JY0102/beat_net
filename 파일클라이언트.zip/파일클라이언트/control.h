//control.h
#pragma once

void con_Init(HWND hDlg);

void con_ServerConnect(HWND hDlg);
void con_ServerDisConnect(HWND hDlg);

void con_SetDownload(HWND hDlg);

void con_FileList();
void con_FileDownLoad(HWND hDLg);
void con_Donwload(HWND hDlg, WPARAM wParam, LPARAM lParam);

void msg_parsing(char* buf);
void file_list_ack(bool flag, FileListAckPacket* packet);
void file_download_ack(bool flag, FileDownloadAckPacket* packet);