//ui.h
#pragma once

void ui_InitControl(HWND hDlg);

void ui_SetDownLoad(HWND hDlg);
void ui_GetDownLoad(HWND hDlg, char* filename, int size);

void ui_FileList_Print(const char(*filenames)[30], int size);
void ui_Reset(HWND hDlg);






