//std.h
#pragma once
#pragma comment(linker, "/subsystem:windows")
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <WinSock2.h>
#pragma comment( lib, "ws2_32.lib")
#include <Windows.h>

#include <commctrl.h>
#include <tchar.h>
#include "resource.h"
#include <vector>
using namespace std; 

#define		BUF_SIZE	2048
#define		PATH_SIZE	260

#define		WM_RECVDOWNDATA		WM_USER + 100

#include "packet.h"		
#include "file.h"		
#include "net.h"		
#include "ui.h"
#include "control.h"
#include "handler.h"
