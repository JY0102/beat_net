#include "std.h"

FileListAckPacket pack_FileListAck()
{
	FileListAckPacket packet;
	packet.flag = PACK_FILE_LIST;

	return packet;
}
FileDownloadPacket pack_FileDownLoad(HWND hDlg)
{
	FileDownloadPacket packet;
	packet.flag = PACK_FILE_DOWNLOAD;
	ui_GetDownLoad(hDlg, packet.filename , sizeof(packet.filename));

	return packet;
}

