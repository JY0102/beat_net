
#define WIN32_LEAN_AND_MEAN
#include <stdio.h>
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <Windows.h>	
#include <winsock2.h>
#include <vector>
using namespace std;


#include "define.h"
#include "user.h"
#include "net.h"
#include "packet.h"
#include "control.h"
#include "app.h"