#include "std.h"


void app_init()
{
	con_init();	
}
void app_run()
{
	con_serverstart();	
}
void app_exit()
{
	con_exit();
}

