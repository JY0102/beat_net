#include "std.h"


vector<USER> users;

HANDLE hThread;

void con_init()
{
	// ���� ����.
	if (net_initlibrary() == false)
	{
		printf(" ���� �ʱ�ȭ����\n\n");
		return;
	}
	
	if (net_create_socket(SERVER_PORT) == false)
	{
		printf(" ���� ���� ���� \n\n");
		return ;
	}
}
void con_serverstart()
{	
	// ��� ������
	
	printf("------ ���� ��� ------\n\n\n");
	hThread = CreateThread(0, 0, listen_thread, 0 , 0, 0);
	if (hThread == 0)
	{
		printf(" �������������� \n");
		return;
	}
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);	
}
void con_exit()
{
	net_delete_socket();
	net_exitlibrary();
}

int msg_login(char* msg)
{
	int* flag = (int*)msg;

	if (*flag == PACKET_LOGIN_USER)
	{
		LoginUserPacket* login = (LoginUserPacket*)msg;
		USER user = user_select_user(login->id, login->pw);
		int idx = find_idx(user.id, user.pw);

		return idx;	
	}

	return NONE;
}
int msg_parsing(char* msg, int num)
{	
	int* flag = (int*)msg;

	switch (*flag)
	{
	// ȸ������
	case PACKET_ADD_USER:
	{		
		AddUserPacket* add = (AddUserPacket*)msg;
		USER user;	
		memset(&user, 0, sizeof(USER));
		strcpy_s(user.id, sizeof(user.id), add->id);
		strcpy_s(user.pw, sizeof(user.pw), add->pw);

		AddUserAckPacket ack;
		memset(&ack, 0, sizeof(AddUserAckPacket));
		if (find_idx(user.id, user.pw) != NONE)
		{
			ack = pack_add_user(false, user.id, user.pw);
		}
		else
		{
			users.push_back(user);
			ack = pack_add_user(true, user.id, user.pw);
		}
		memcpy_s(msg, sizeof(AddUserAckPacket), (char*)&ack, sizeof(AddUserAckPacket));
		return sizeof(AddUserAckPacket);		
	}
	// �α���
	case PACKET_LOGIN_USER:
	{		
		LoginUserAckPacket ack;
		if (num == NONE)
		{
			 ack = pack_login_user(num, 0,0,0);
		}
		else
		{
			ack = pack_login_user(num, users[num].money, users[num].asset, ASSET_SIZE);
		}
		memcpy_s(msg, sizeof(LoginUserAckPacket), &ack, sizeof(LoginUserAckPacket));
		return sizeof(LoginUserAckPacket);
	}
	// �� ����
	case PACKET_ADD_MONEY:
	{
		AddMoneyPacket* money = (AddMoneyPacket*)msg;
		AddMoneyAckPacket ack;
		memset(&ack, 0, sizeof(AddMoneyAckPacket));
		if( money->money == users[num].money)
		{
			users[num].money += PLUS_MONEY;
			ack = pack_add_money(true, users[num].money);
		}

		memcpy_s(msg, sizeof(AddMoneyAckPacket), &ack, sizeof(AddMoneyAckPacket));
		return sizeof(AddMoneyAckPacket);
	}
	// ��ǰ ����
	case PACKET_ADD_ASSET:
	{
		AddAssetPacket* asset = (AddAssetPacket*)msg;
		int type  = add_asset_type(users[num].asset, asset->asset);
		int check = buy_asset(type, asset->money);
		if (check != NONE)
		{
			asset->asset[type] = true;
		}

		AddAssetAckPacket ack = pack_add_asset(check, asset->money, asset->asset);
		memcpy_s(msg, sizeof(AddAssetAckPacket), &ack, sizeof(AddAssetAckPacket));

		return sizeof(AddAssetAckPacket);
	}
	}
	return 0;
}

int find_idx(const char* id, const char* pw)
{
	USER user;
	for (int i = 0; i < users.size(); i++)
	{
		user = users[i];
		if ((strcmp(user.id, id) == 0) && (strcmp(user.pw, pw) == 0))
		{
			return i;
		}
	}

	return NONE;
}
int add_asset_type(const bool* sever_asset, bool* client_asset)
{
	for (int i = 0; i < ASSET_SIZE; i++)
	{
		if(sever_asset[i] != client_asset[i])
				return i;
	}
	return NONE;
}
int buy_asset(int type , int money)
{
	switch (type)
	{
		case VANGOGH:		
		{
			if (money > PRICE_VANGOGH)
			{
				return (money - PRICE_VANGOGH);
			}
			else
			{
				return NONE;
			}
		}
		case PICASSO:	
		{
			if (money > PRICE_PICASSO)
			{
				return (money - PRICE_PICASSO);
			}
			else
			{
				return NONE;
			}
		}
		case HOUSE	:	
		{
			if (money > PRICE_HOUSE)
			{
				return (money - PRICE_HOUSE);
			}
			else
			{
				return NONE;
			}
		}
		case APT:
		{
			if (money > PRICE_APT)
			{
				return (money - PRICE_APT);
			}
			else
			{
				return NONE;
			}
		}
		case HOTEL:
		{
			if (money > PRICE_HOTEL)
			{
				return (money - PRICE_HOTEL);
			}
			else
			{
				return NONE;
			}
		}
		case JONGANG:
		{
			if (money > PRICE_JONGANG)
			{
				return (money - PRICE_JONGANG);
			}
			else
			{
				return NONE;
			}
		}
	}
	return NONE;
}
