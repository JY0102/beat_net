#include "std.h"

SOCKET g_listen_socket;

bool net_initlibrary()
{
	WSADATA wsa;

	if (WSAStartup((MAKEWORD(2, 2)), &wsa) != 0)
	{
		return false;
	}
	return true;
}
void net_exitlibrary()
{
	WSACleanup();
}

bool net_create_socket(int port)
{
	g_listen_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (g_listen_socket == INVALID_SOCKET)
	{
		printf(" ���� ���� ����\n");
		return false;
	}
	SOCKADDR_IN addr;
	memset(&addr, 0, sizeof(SOCKADDR_IN));

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(port);

	int ret = bind(g_listen_socket, (SOCKADDR*)&addr, sizeof(addr));
	if (ret == SOCKET_ERROR)
	{
		printf(" bind  ����\n");
		return false;
	}

	ret = listen(g_listen_socket, SOMAXCONN);
	if (ret == SOCKET_ERROR)
	{
		printf(" listen  ����\n");
		return false;
	}

	return true;
}
void net_delete_socket()
{
	closesocket(g_listen_socket);
}

int send_data(SOCKET s, char* buf, int len, int flag)
{
	int send_byte = send(s, (char*)&len, sizeof(int), flag);
	send_byte = send(s, buf, len, flag);

	return send_byte;
}

int recv_data(SOCKET s, char* buf, int len, int flag)
{
	// ��� recv
	int size;
	int ret = recvn(s, (char*)&size, sizeof(int), flag);
	if (ret == SOCKET_ERROR)
	{
		return SOCKET_ERROR;
	}
	else if (ret == 0)
	{
		return 0;
	}

	// ������ ũ�� ��ŭ  �����͸� ����.
	ret = recvn(s, buf, size, 0);
	return ret;
}
int recvn(SOCKET s, char* buf, int len, int flag)
{
	int recv_byte;
	char* ptr = buf;
	int left = len;

	while (left > 0)
	{
		recv_byte = recv(s, ptr, left, flag);
		if (recv_byte == SOCKET_ERROR)
		{
			return SOCKET_ERROR;
		}
		else if (recv_byte == 0)
		{
			break;
		}

		left -= recv_byte;
		ptr += recv_byte;
	}

	return (len - left);

}
// ��� ���� ������
unsigned long CALLBACK listen_thread(void* temp)
{
	
	SOCKADDR_IN client_addr;
	int client_length = sizeof(SOCKADDR_IN);

	while (true)
	{
		memset(&client_addr, 0, sizeof(SOCKADDR_IN));
		SOCKET socket = accept(g_listen_socket, (SOCKADDR*)&client_addr, &client_length);
		if (socket == INVALID_SOCKET)
		{
			printf(" accept  ����\n");
			Sleep(2000);
			continue;
		}
		printf("------ ���� ���� : (%s : %d )------\n\n\n",
			inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

		// ��� ���� �� ������ ����
		HANDLE hThread = CreateThread(0, 0, work_thread, (void*)socket, 0, 0);
		if (hThread == 0)
		{
			printf(" workthread ����\n");
			return -1;
		}

		CloseHandle(hThread);
	}
	return 0;
}
// ��� ���� �ϴ� ��
unsigned long CALLBACK work_thread(void* p)
{	// ��� ���� ����
	SOCKET client_socket = (SOCKET)p;
	char buf[1024];
	int num = NONE;
	while (true)
	{
		memset(buf, 0, sizeof(buf));
		int recv_byte = recv_data(client_socket, buf, sizeof(buf), 0);
		if (recv_byte == 0)
		{
			printf("------ ���� ������ ������ϴ� ------\n\n");
			break;
		}
		else if (recv_byte == -1)
		{
			printf("\n\n  ERROR  \n\n");
			break;
		}
		else
		{
			char FLAG[20];
			int* flag = (int*)buf;
			switch (*flag)
			{
			case PACKET_ADD_USER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "ȸ������");
				break;
			}
			case PACKET_LOGIN_USER:
			{
				strcpy_s(FLAG, sizeof(FLAG), "�α���");
				break;
			}
			case PACKET_ADD_MONEY:
			{
				strcpy_s(FLAG, sizeof(FLAG), "������");
				break;
			}
			case PACKET_ADD_ASSET:
			{
				strcpy_s(FLAG, sizeof(FLAG), "����");
				break;
			}
			}
			SOCKADDR_IN client_addr;
			int client_length = sizeof(SOCKADDR);
			getpeername(client_socket, (SOCKADDR*)&client_addr, &client_length);

			printf(">> [����] IP : %s �������� : %s <<\n\n",
				inet_ntoa(client_addr.sin_addr), FLAG);
			// �޼��� �Ľ�
			if(num == NONE)
			{
				num = msg_login(buf);
			}
			int size = msg_parsing(buf,num);
			int send_byte = send_data(client_socket, buf, size, 0);
			printf(">> [�۽�] IP : %s <<\n\n", inet_ntoa(client_addr.sin_addr));
		}
	}

	SOCKADDR_IN client_addr;
	int client_length = sizeof(SOCKADDR);

	getpeername(client_socket, (SOCKADDR*)&client_addr, &client_length);

	printf("------ Ŭ���̾�Ʈ ���� ���� (IP :%s ) ------\n\n\n",
		inet_ntoa(client_addr.sin_addr));

	closesocket(client_socket);
	return 0;
}
