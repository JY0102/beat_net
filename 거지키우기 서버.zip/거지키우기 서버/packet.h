#pragma once

// ��� ȸ������
#define PACKET_ADD_USER			1
#define PACKET_ADD_USER_S		11
#define PACKET_ADD_USER_F		12
// ��� �α���
#define PACKET_LOGIN_USER		2
#define PACKET_LOGIN_USER_S		21
#define PACKET_LOGIN_USER_F		22
// �� ����
#define PACKET_ADD_MONEY		3
#define PACKET_ADD_MONEY_S		31
#define PACKET_ADD_MONEY_F		32
// ���� ����
#define PACKET_ADD_ASSET		4
#define PACKET_ADD_ASSET_S		41
#define PACKET_ADD_ASSET_F		42


//ȸ������	
struct  AddUserPacket
{	
	int flag;
	char id[20];
	char pw[20];
};
typedef AddUserPacket		AddUserAckPacket;
// �α���
typedef AddUserPacket		LoginUserPacket;
struct  LoginUserAckPacket
{
	int flag;
	int money;
	bool asset[ASSET_SIZE];
};
// �� ����
struct  AddMoneyPacket
{
	int flag;
	int money;
};
typedef AddMoneyPacket		AddMoneyAckPacket;
// ���� ����
typedef LoginUserAckPacket	AddAssetPacket;
typedef AddAssetPacket		AddAssetAckPacket;

AddUserAckPacket   pack_add_user(bool flag,const char*id, const char* pw);
LoginUserAckPacket pack_login_user(int idx, int money, bool* asset , int asset_size);
AddMoneyAckPacket  pack_add_money(bool flag , int money);
AddAssetAckPacket  pack_add_asset(int flag , int money, bool* asset);