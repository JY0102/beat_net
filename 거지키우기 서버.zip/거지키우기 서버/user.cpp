#include "std.h"


USER user_create_user(const char* id, const char* pw)
{
	USER user;
	
	strcpy_s(user.id, sizeof(user.id), id);
	strcpy_s(user.pw, sizeof(user.pw), pw);
	return user;
}
USER user_select_user(const char* id, const char* pw)
{
	USER user;	
	memset(&user, 0, sizeof(USER));
	strcpy_s(user.id, sizeof(user.id), id);
	strcpy_s(user.pw, sizeof(user.pw), pw);

	return user;
}
USER user_add_money(int money)
{
	USER user;
	
	user.money = money;
	return user;
}
USER user_add_asset(int money, int* asset)
{
	USER user;

	user.money = money;
	memcpy(user.asset, asset, sizeof(user.asset));

	return user;
}