#pragma once

int find_idx(const char* id, const char* pw);
int add_asset_type(const bool* sever_asset, bool* client_asset);
int buy_asset(int type, int money);

int msg_login(char* msg);
int msg_parsing(char* msg, int num);

unsigned long CALLBACK listen_thread(void* temp);
unsigned long CALLBACK work_thread(void* p);

void con_init();
void con_serverstart();
void con_exit();

int find_idx(const char* id, const char* pw);
int add_asset_type(const bool* sever_asset, bool* client_asset);
