#include "std.h"



AddUserAckPacket pack_add_user(bool flag, const char* id, const char* pw)
{
	AddUserAckPacket ack;
	memset(&ack, 0, sizeof(AddUserAckPacket));
	ack.flag = PACKET_ADD_USER_S;

	return ack;
}
LoginUserAckPacket pack_login_user(int idx,int money , bool* asset , int asset_size)
{
	LoginUserAckPacket ack;
	memset(&ack, 0, sizeof(LoginUserAckPacket));
	if (idx != NONE)
	{		
		ack.flag = PACKET_LOGIN_USER_S;
		ack.money = money;
		if (asset != nullptr) {
			memcpy_s(ack.asset, sizeof(ack.asset), asset, asset_size*sizeof(bool));
		}
	}
	else
	{
		ack.flag = PACKET_LOGIN_USER_F;
	}

	return ack;
}
AddMoneyAckPacket pack_add_money(bool flag, int money)
{
	AddMoneyAckPacket ack;
	memset(&ack, 0, sizeof(AddMoneyAckPacket));
	if (flag == true)
	{
		ack.flag = PACKET_ADD_MONEY_S;
		ack.money = money;
	}
	else
	{
		ack.flag = PACKET_ADD_MONEY_F;
		ack.money = money;
	}

	return ack;
}
AddAssetAckPacket pack_add_asset(int check, int money , bool* asset)
{
	AddAssetAckPacket ack;
	memset(&ack, 0, sizeof(AddAssetAckPacket));
	if (check != NONE)
	{
		ack.flag = PACKET_ADD_ASSET_S;
		ack.money = check - money;
		memcpy_s(ack.asset, sizeof(ack.asset), asset, sizeof(asset));
	}
	else
	{
		ack.flag = PACKET_ADD_MONEY_F;
		ack.money = money;
		memcpy_s(ack.asset, sizeof(ack.asset), asset, sizeof(asset));
	}
	
	return ack;
}