#pragma once

struct USER
{	
	char id[20];
	char pw[20];
	int money;
	bool asset[ASSET_SIZE];
};

USER user_create_user(const char* id, const char* pw);
USER user_select_user(const char* id, const char* pw);
USER user_add_money(int money);
USER user_add_asset(int money, int* asset);
