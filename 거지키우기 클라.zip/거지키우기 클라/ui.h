//ui.h
#pragma once





void ui_GetInsertData(HWND hDlg, TCHAR* id, int id_size, TCHAR* pw, int pw_size);
void ui_GetMoneyData(HWND hDlg, int* money);
void ui_GetAssetData(HWND hDlg, bool* asset);








