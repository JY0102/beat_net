﻿//ui.cpp
#include "std.h"







void ui_GetInsertData(HWND hDlg, TCHAR* id, int id_size, TCHAR* pw, int pw_size)
{
	GetDlgItemText(hDlg, IDC_EDITID, id, id_size);
	GetDlgItemText(hDlg, IDC_EDITPW, pw, pw_size);	
}
void ui_GetMoneyData(HWND hDlg, int* money)
{
	money = (int*)GetDlgItemInt(hDlg, IDC_EDITMONEY, 0, 0);
}
void ui_GetAssetData(HWND hDlg, bool* asset)
{
	//memcpy_s(ack.asset, sizeof(ack.asset), asset, sizeof(asset));
}