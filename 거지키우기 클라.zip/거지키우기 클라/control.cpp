//control.cpp
#include "std.h"

// ���� ��޸��� �ڵ�
HWND main_hDlg;
// �ڵ� ��
HWND g_hDlg;
USER g_user;
void con_Init(HWND hDlg)
{
	g_hDlg = hDlg;

	if (net_initlibrary() == false)
	{
		EndDialog(hDlg, -1);
	}
	if (net_create_socket(SERVER_IP , SERVER_PORT) == false)
	{
		EndDialog(hDlg, -1);
	}
}

void con_ServerConnect(HWND hDlg)
{
	if (net_initlibrary() == false)
	{
		printf("���� �ʱ�ȭ ����\n");
		//EndDialog(hDlg, IDCANCEL);
	}

	if (net_create_socket(SERVER_IP, SERVER_PORT) == false)
	{
		MessageBox(hDlg, TEXT("�����������"), TEXT("�˸�"), MB_OK);
		//EndDialog(hDlg, IDCANCEL);
	}
}
void con_ServerDisConnect(HWND hDlg)
{
	net_delete_socket();
	net_exitlibrary();
	MessageBox(hDlg, TEXT("������������ ����"), TEXT("�˸�"), MB_OK);
}

void con_AddUser(HWND hDlg)
{
	TCHAR id[20];
	TCHAR pw[20];

	try
	{
		ui_GetInsertData(hDlg, id, _countof(id), pw, _countof(pw));

		AddUserPacket packet = pack_add_user(id,pw);
		send_data((char*)&packet, sizeof(packet), 0);
	}
	catch (const TCHAR* msg)
	{
		MessageBox(hDlg, msg, TEXT("ȸ������ ����"), MB_OK);
	}
}
void con_LoginUser(HWND hDlg)
{
	TCHAR id[20];
	TCHAR pw[20];

	try
	{
		ui_GetInsertData(hDlg, id, _countof(id), pw, _countof(pw));
		AddUserPacket packet = pack_login_user(id, pw);
		send_data((char*)&packet, sizeof(packet), 0);
	}
	catch (const TCHAR* msg)
	{
		MessageBox(hDlg, msg, TEXT("�α��� ����"), MB_OK);
	}
}
void con_AddMoney(HWND hDlg)
{
	int money;

	try
	{
		ui_GetMoneyData(hDlg, &money);
		AddMoneyPacket packet = pack_add_money(money);
		send_data((char*)&packet, sizeof(packet), 0);
	}
	catch (const TCHAR* msg)
	{
		MessageBox(hDlg, msg, TEXT("���߰� ����"), MB_OK);
	}
}
void con_AddAsset(HWND hDlg, int type)
{
	int money;	
	try
	{
		ui_GetMoneyData(hDlg, &money);
		g_user.asset[type] = true;

		AddAssetPacket packet = pack_add_asset(money , g_user.asset);
		send_data((char*)&packet, sizeof(packet), 0);
	}
	catch (const TCHAR* msg)
	{
		MessageBox(hDlg, msg, TEXT("Add asset"), MB_OK);
	}
}

//---------- �����Լ��� -----------------------------------------------
void msg_parsing(char* buf)
{
	//�Ľ�
	switch (*(int*)buf)
	{
	case PACKET_ADD_USER_S:		return add_user_ack	 (true ,(AddUserAckPacket*)buf);
	case PACKET_ADD_USER_F:		return add_user_ack	 (false,(AddUserAckPacket*)buf);
	case PACKET_LOGIN_USER_S:   return login_user_ack(true, (LoginUserAckPacket*)buf);
	case PACKET_LOGIN_USER_F:	return login_user_ack(false,(LoginUserAckPacket*)buf);
	case PACKET_ADD_MONEY_S:	return add_money_ack (true, (AddMoneyAckPacket*)buf);
	case PACKET_ADD_MONEY_F:	return add_money_ack (false,(AddMoneyAckPacket*)buf);
	case PACKET_ADD_ASSET_S:	return add_accet_ack (true, (AddAssetAckPacket*)buf);
	case PACKET_ADD_ASSET_F:	return add_accet_ack (false,(AddAssetAckPacket*)buf);
	}
}

void add_user_ack(bool flag, AddUserAckPacket* buf)
{

	if (flag == true)
		MessageBox(NULL, TEXT("ȸ������ ����"), TEXT("ȸ������"), MB_OK);
	else
		MessageBox(NULL, TEXT("ȸ������ ����"), TEXT("ȸ������"), MB_OK);
}
void login_user_ack(bool flag, LoginUserAckPacket* buf)
{
	if (flag == true)
	{
		pack_ack_login_user(buf, &g_user);
		if(main_hDlg == NULL)
		{
			main_hDlg = CreateDialogParam(GetModuleHandle(0), MAKEINTRESOURCE(IDD_DIALOG2), g_hDlg,
				GameProc, (LPARAM)buf);
			ShowWindow(main_hDlg, SW_SHOW);
		}

		else
		{
			SetFocus(main_hDlg);
		}
	}
	else
	{
		MessageBox(NULL, TEXT("�α��� ����"), TEXT("�α���"), MB_OK);
	}
}
void add_money_ack(bool flag, AddMoneyAckPacket* buf)
{
	if (flag == true)
	{
		g_user.money = buf->money;
		SendMessage(main_hDlg, WM_ADD_MONEY, 0, (LPARAM)g_user.money);
	}
	else
	{
		MessageBox(NULL, TEXT("������ ����"), TEXT("������"), MB_OK);
	}
}
void add_accet_ack(bool flag, AddAssetAckPacket* buf)
{
	if (flag == true)
	{		
		memcpy_s(g_user.asset, sizeof(g_user.asset), buf->asset, sizeof(buf->asset));
		SendMessage(main_hDlg, WM_ADD_ASSET, 0, (LPARAM)&g_user);
	}
	else
	{
		MessageBox(NULL, TEXT("���� ���� ����"), TEXT("����"), MB_OK);
	}
}