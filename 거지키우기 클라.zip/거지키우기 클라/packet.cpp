//packet.cpp
#include "std.h"

AddUserPacket   pack_add_user( const char* id, const char* pw)
{
	AddUserPacket ack;
	memset(&ack, 0, sizeof(AddUserAckPacket));
	ack.flag = PACKET_ADD_USER;
	strcpy_s(ack.id, sizeof(ack.id), id);
	strcpy_s(ack.pw, sizeof(ack.pw), pw);

	return ack;
}
LoginUserPacket pack_login_user(const char* id, const char* pw)
{
	LoginUserPacket ack;
	ack.flag = PACKET_LOGIN_USER;
	strcpy_s(ack.id, sizeof(ack.id), id);
	strcpy_s(ack.pw, sizeof(ack.pw), pw);

	return ack;
}
AddMoneyPacket  pack_add_money(int money)
{
	AddMoneyPacket ack;
	memset(&ack, 0, sizeof(AddMoneyPacket));
	ack.flag = PACKET_ADD_MONEY;
	ack.money = money;

	return ack;
}
AddAssetPacket  pack_add_asset(int money, bool* asset)
{
	AddAssetAckPacket ack;
	memset(&ack, 0, sizeof(AddAssetAckPacket));
	ack.flag = PACKET_ADD_MONEY;
	ack.money = money;
	memcpy_s(ack.asset, sizeof(ack.asset), asset, sizeof(asset));

	return ack;
}


void pack_ack_login_user(LoginUserAckPacket* msg, USER* puser)
{	
	puser ->money = msg->money;
	memcpy_s(puser->asset, sizeof(puser->asset), msg->asset, sizeof(msg->asset));
	return ;
}