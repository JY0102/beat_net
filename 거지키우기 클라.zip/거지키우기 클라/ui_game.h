#pragma once

//void ui_InitControl(HWND hDlg);
//void ui_MemberPrint(HWND hDlg, bool* asset);


INT_PTR CALLBACK GameProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);