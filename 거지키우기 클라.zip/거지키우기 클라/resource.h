//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 0320_ȸ���������α׷�.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     103
#define IDC_EDIT1                       1001
#define IDC_EDITID                      1001
#define IDC_EDITMONEY                   1001
#define IDC_EDIT2                       1002
#define IDC_EDITPW                      1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT5                       1005
#define IDC_BUTTON1                     1006
#define IDC_BUTTONADD                   1006
#define IDC_BUTTONMONEY                 1006
#define IDC_EDIT6                       1007
#define IDC_BUTTONLOGIN                 1007
#define IDC_EDIT7                       1008
#define IDC_LIST2                       1010
#define IDC_LIST1                       1011
#define IDC_BUTTON2                     1012
#define IDC_BUTTONSTORE                 1012
#define IDC_EDIT8                       1013
#define IDC_EDIT9                       1014
#define IDC_EDIT10                      1015
#define IDC_EDIT11                      1016
#define IDC_EDIT12                      1017
#define IDC_BUTTON3                     1018
#define IDC_BUTTON4                     1019
#define IDC_BUTTON5                     1020
#define IDC_BUTTON6                     1021
#define IDC_BUTTON7                     1022
#define IDC_BUTTON8                     1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
