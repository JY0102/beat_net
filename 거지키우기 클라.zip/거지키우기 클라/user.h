#pragma once

struct USER
{
	TCHAR id[20];
	TCHAR pw[20];
	int   money;
	bool  asset[ASSET_SIZE];
};
