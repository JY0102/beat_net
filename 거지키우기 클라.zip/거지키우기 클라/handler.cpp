//handler.cpp
#include "std.h"

INT_PTR OnInitDialog(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	con_Init(hDlg);
	return TRUE;
}
INT_PTR OnCommand(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	//���α׷� ����
	if (LOWORD(wParam) == IDCANCEL)
	{
		net_delete_socket();
		net_exitlibrary();
		EndDialog(hDlg, IDCANCEL);
		return TRUE;
	}
	//ȸ������
	else if (LOWORD(wParam) == IDC_BUTTONADD)
	{
		con_AddUser(hDlg);
		return TRUE;
	}
	//�α���
	else if (LOWORD(wParam) == IDC_BUTTONLOGIN)
	{
		con_LoginUser(hDlg);
		return TRUE;
	}
	//������
	else if (LOWORD(wParam) == IDC_BUTTONMONEY)
	{
		con_AddMoney(hDlg);
		return TRUE;
	}   
	//���� ����
	else if (HIWORD(wParam) == BN_CLICKED)
	{
		switch (LOWORD(wParam))
		{
		case IDC_BUTTON1:
		{
			con_AddAsset(hDlg, VANGOGH);
			return TRUE;
		}
		case IDC_BUTTON2:
		{
			con_AddAsset(hDlg, PICASSO);
			return TRUE;
		}
		case IDC_BUTTON3:
		{
			con_AddAsset(hDlg, HOUSE);
			return TRUE;
		}
		case IDC_BUTTON4:
		{
			con_AddAsset(hDlg, APT);
			return TRUE;
		}
		case IDC_BUTTON5:
		{
			con_AddAsset(hDlg, HOTEL);
			return TRUE;
		}
		case IDC_BUTTON6:
		{
			con_AddAsset(hDlg, JONGANG);
			return TRUE;
		}
		}
	}
	//���� ����
	else if (LOWORD(wParam) == IDC_BUTTON7)
	{
		con_ServerConnect(hDlg);
		return TRUE;
	}
	//���� ���� ����
	else if (LOWORD(wParam) == IDC_BUTTON8)
	{
		con_ServerDisConnect(hDlg);
		return TRUE;
	}
	return FALSE;
}
