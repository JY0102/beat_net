//control.h
#pragma once

void con_Init(HWND hDlg);

//��ư �̺�Ʈ
//WM_INITDIALOG, WM_COMMAND(IDC_CANCEL)
void con_ServerConnect(HWND hDlg);
void con_ServerDisConnect(HWND hDlg);

void con_AddUser(HWND hDlg);
void con_LoginUser(HWND hDlg);
void con_AddMoney(HWND hDlg);
void con_AddAsset(HWND hDlg, int type);

void msg_parsing(char* buf);
void add_user_ack(bool flag, AddUserAckPacket* buf);
void login_user_ack(bool flag, LoginUserAckPacket* buf);
void add_money_ack(bool flag, AddMoneyAckPacket* buf);
void add_accet_ack(bool flag, AddAssetAckPacket* buf);


