#include "std.h"

HWND hList;

TCHAR asset_info[ASSET_SIZE][10] =
{
_T("�ݰ���"),
_T("��ī��"),
_T("��"),
_T("����Ʈ"),
_T("ȣ��"),
_T("����"),
};
TCHAR asset_price[ASSET_SIZE][20] =
{
	{"100"},
	{"200"},
	{"300"},
	{"400"},
	{"500"},
	{"600"}
};

//void ui_InitControl(HWND hDlg)
//{
//	hList = GetDlgItem(hDlg, IDC_LIST2);
//
//	//����Ʈ�信 ���
//	LVCOLUMN COL;
//
//	COL.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
//	COL.fmt = LVCFMT_LEFT;
//	COL.cx = 150;
//	COL.pszText = (LPTSTR)TEXT("�̸�");
//	COL.iSubItem = 0;
//	SendMessage(hList, LVM_INSERTCOLUMN, 0, (LPARAM)&COL);
//
//	COL.pszText = (LPTSTR)TEXT("����");
//	COL.iSubItem = 1;
//	SendMessage(hList, LVM_INSERTCOLUMN, 1, (LPARAM)&COL);
//
//	COL.pszText = (LPTSTR)TEXT("���� ����");
//	COL.iSubItem = 2;
//	SendMessage(hList, LVM_INSERTCOLUMN, 2, (LPARAM)&COL);
//
//	ListView_SetExtendedListViewStyle(hList, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_HEADERDRAGDROP);
//	// LVS_EX_FULLROWSELECT |LVS_EX_GRIDLINES | LVS_EX_CHECKBOXES | LVS_EX_HEADERDRAGDROP);
//}
//void ui_MemberPrint(HWND hDlg, bool* asset)
//{
//	TCHAR have[10];
//	SendMessage(hList, LVM_DELETEALLITEMS, 0, 0);
//	LVITEM LI;
//	for (int i = 0; i < ASSET_SIZE; i++)
//	{
//		LI.mask = LVIF_TEXT;
//		LI.iItem = 0;
//
//		LI.iSubItem = 0;
//		LI.pszText = asset_info[i];
//		SendMessage(hList, LVM_INSERTITEM, i, (LPARAM)&LI);
//
//		LI.iSubItem = 1;
//		LI.pszText = asset_price[i];
//		SendMessage(hList, LVM_SETITEM, i, (LPARAM)&LI);
//
//		LI.iSubItem = 2;
//		if (asset[i] == true)
//		{
//			strcpy_s(have, _countof(have), _T("������"));
//		}
//		else
//		{
//			strcpy_s(have, _countof(have), _T("����"));
//		}
//		LI.pszText = have;
//		SendMessage(hList, LVM_SETITEM, i, (LPARAM)&LI);
//	}
//}

INT_PTR CALLBACK GameProc(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static LoginUserAckPacket *g_user;
	switch (msg)
	{
	case WM_INITDIALOG:
	{
		g_user = (LoginUserAckPacket*)lParam;
		//ui_InitControl(hDlg);
		//ui_MemberPrint(hDlg, g_user->asset);
		return TRUE;
	}
	//case WM_COMMAND:
	//{
	//	if (LOWORD(wParam) == IDCANCEL)
	//	{
	//		EndDialog(hDlg, 0);
	//		return TRUE;
	//	}
	//	break;
	//}
	//case WM_ADD_MONEY:
	//{
	//	g_user->money = (int)lParam;
	//	SetDlgItemInt(hDlg, IDC_EDITMONEY, g_user->money, 0);
	//	ui_MemberPrint(hDlg, g_user->asset);
	//	return TRUE;
	//}
	//case WM_ADD_ASSET:
	//{
	//	USER* add = (USER*)lParam;
	//	g_user->money = add->money;
	//	SetDlgItemInt(hDlg, IDC_EDITMONEY, g_user->money, 0);
	//	memcpy_s(g_user->asset, sizeof(g_user->asset), add->asset, sizeof(add->asset));
	//	ui_MemberPrint(hDlg, g_user->asset);
	//	return TRUE;
	//}
	}

	return FALSE;
}